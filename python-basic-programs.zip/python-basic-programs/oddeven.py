i=0
while i<3:
    x = int(input('Enter a number: '))
    if x%2==0:
        print("The number is even.")
    else:
        print("The number is odd.")
    i+=1
