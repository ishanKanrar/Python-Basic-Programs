i=4000
k=0
prime=[]
while i<=4000 and k<3:
    f=1
    for x in range(2,i-1):
        if i%x==0:
            f=0
            break
    if f==1:
        k+=1
        prime.append(i)
    i-=1

print(prime)

# output

# [3989, 3967, 3947]