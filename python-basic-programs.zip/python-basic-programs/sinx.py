import math
sum=0
s=0
e=1
n=int(input('Enter the number of terms: '))
x=int(input('Enter the number: '))
for i in range(1,n+1):
    # j=i+1
    sign = (-1)**(i-1)
    sum = sum + (((x)**i)/math.factorial(i))*sign
    i=i+1
    # e=sum-s
    # s=sum
    # if e>0.01 or e>0 :
    #     break
print('sum of the series is : ',('{0:.9f}' .format(sum)))

