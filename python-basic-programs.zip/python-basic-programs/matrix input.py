r= int(input('enter the number of rows :'))
c= int(input('enter the number of columns :'))
mat1=[]
mat2=[]
print('enter the elements for first matrix :')
for i in range(r):
    a=[]
    for j in range(c):
        a.append(int(input()))
    mat1.append(a)  


print('enter the elements for second matrix :')
for i in range(r):
    a=[]
    for j in range(c):
        a.append(int(input()))
    mat2.append(a)
mat3=[]
for i in range(r):
    a=[]
    for j in range(c):
        a.append(mat1[i][j]+mat2[i][j])
    mat3.append(a)
print('sum of two matrices :')
for i in range(r):
    for j in range(c):
        print(mat3[i][j], end=" ")
    print()