x=[[2,5],[8,5]]
y=[[7,5],[8,2]]
r=[[0,0],[0,0]]
for i in range(len(x)):
    for j in range(len(x[0])):
        # r[i][j]=x[i][j]+y[i][j]      add
        r[i][j]=x[i][j]-y[i][j]         #sub
for k in r:
    print(k)