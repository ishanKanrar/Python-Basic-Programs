# print("hamedani")
# print('*' * 10)
# a = 10
# print(a)

# name = input('What is your name?')
# print('Hi! ' + name)

# birthYear = input('Birth Year: ')
# print(type(birthYear))
# age = 2019 - int(birthYear)
# print(type(age))
# print(age)

#MULTI line string

s = '''
Hi, 
this is the first email
thank you,
support team
'''
s1 = 'Pythone for beginners'
# print(s1[-2])
# print(s1[1:4])

#formatted string
fname = 'john'
lname = 'smith'
s2 = f'{fname} {lname} is a coder'
print(s2)