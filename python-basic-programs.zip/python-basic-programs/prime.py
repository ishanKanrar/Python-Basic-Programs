# x=int(input('Enter a number:' ))
prime = [] 
l=int(input('Enter the lower limit: '))
u=int(input('Enter the upper limit: '))

for x in range(l,u+1):
    flag=1
    for i in range(2,x-1):
        if x%i==0:
            flag=0
            break
    if flag==1:
        prime.append(x)
    # else:
    #     print (f'{x} is not a prime number')
print (prime)